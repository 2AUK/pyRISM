from .IE import IntegralEquation
