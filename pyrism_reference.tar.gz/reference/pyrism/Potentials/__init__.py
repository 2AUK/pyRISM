from .potential_dispatcher import Potential
